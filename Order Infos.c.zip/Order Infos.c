#include <stdio.h>
#define TAX_RATE 20
#define DISCOUNT 0.9

unsigned short qa1, qa2, qa3;
float price1, price2, price3, net_total_price;


void _handle_order(unsigned short, unsigned short);
void __compute_tax_and_total_price();


void init_stock() {
    printf("*************Initializing Stock*************\n");
    printf("Enter the available quantity of product 1: ");
    scanf("%hu", &qa1);
    printf("Enter the price of product 1: ");
    scanf("%f", &price1);

    printf("Enter the available quantity of product 2: ");
    scanf("%hu", &qa2);
    printf("Enter the price of product 2: ");
    scanf("%f", &price2);

    printf("Enter the available quantity of product 3: ");
    scanf("%hu", &qa3);
    printf("Enter the price of product 3: ");
    scanf("%f", &price3);
}


void handle_customer() {
    
    int feedback = 1, index, quantity;
    net_total_price = 0.0;
    printf("*************Handling a new customer*************\n");
    do {
        printf("Choose product [1, 2, 3]: ");
        scanf("%d", &index);
        if (index < 1 || index > 3) {
            printf("Sorry. The selected product does not exist\n");
            continue; 
            
        }
              
        printf("Select quantity: ");
        scanf("%d", &quantity);
        _handle_order(index, quantity);
        printf("\nEnter 1 to continue or any other number to stop: ");
        scanf("%d", &feedback);
    } while (feedback == 1);
}
void _handle_order(unsigned short index, unsigned short quantity) {
    switch (index) {
        case 1:
            if (quantity <= qa1) {
                net_total_price += price1 * quantity;
                qa1 -= quantity;
                __compute_tax_and_total_price();
            } else {
                printf("Sorry, ordered quantity is not available\n");
            }
        break;
        case 2:
            if (quantity <= qa2) {
                net_total_price += price2 * quantity;
                qa2 -= quantity;
                __compute_tax_and_total_price();
            } else {
                printf("Sorry, ordered quantity is not available\n");
            }
        break;
        case 3:
            if (quantity <= qa3) {
                net_total_price += price1 * quantity;
                qa3 -= quantity;
                __compute_tax_and_total_price();
            } else {
                printf("Sorry, ordered quantity is not available\n");
            }
        break;
        default:
            printf("Sorry. The selected product does not exist\n");
    }
    
}
void __compute_tax_and_total_price() {
    
    float tax, total_price;

    tax = net_total_price * TAX_RATE / 100;
    total_price = net_total_price + tax;

    printf("Net total price so far: %.2f\n", net_total_price);
    if (net_total_price > 1000){
        printf("you have a 10 prc discount");
        net_total_price *= DISCOUNT; 
    }
    printf("Tax so far: %.2f\n", tax);
    printf("Total price so far: %.2f\n", total_price);
}